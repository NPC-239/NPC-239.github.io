This version is free for personal and commercial use

Buy a ZT Bros Oskon 90s complete family:
https://zelowtype.gumroad.com/l/ztbrososkon90s

Appreciate and follow:
https://www.behance.net/zelowtype

ZT Bros Oskon 90s is a captivating typographic creation that seamlessly blends the aesthetic charm of the 1990s retro era with a modern touch. With unmatched serif elegance and a unique 90s style, this font offers 72 variations, including sharp condensed forms, graceful expansions, and captivating italic styles.

Every character in ZT Bros Oskon 90s is meticulously crafted, creating a vintage ambiance that is truly enchanting. Featuring 6 font weights ranging from Extra Light to Bold, this font provides you with the flexibility to create a wide range of striking and memorable designs.

Features of ZT Bros Oskon 90s:

72 Unique Variations

Aesthetic Retro Vibes from the 1990s

Elegant Serif Style

Condensed, Expanded, and Italic Forms

6 Font Weights: Extra Light, Light, Regular, Medium, Semi-Bold, Bold

Exceptional Creative Versatility

ZT Bros Oskon 90s is the perfect choice for graphic design projects, branding, posters, and other promotional materials that require a captivating retro touch. Unleash limitless creativity with this font and infuse a nostalgic 1990s vibe into every one of your creations.

I hope you have fun using ZT Bros Oskon 90s.

Thanks for using this font ~ Zelowtype
